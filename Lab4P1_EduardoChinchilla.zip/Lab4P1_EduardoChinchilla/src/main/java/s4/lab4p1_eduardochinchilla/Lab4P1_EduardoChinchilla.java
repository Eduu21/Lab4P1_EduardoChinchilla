
package s4.lab4p1_eduardochinchilla;

import java.util.Scanner;

public class Lab4P1_EduardoChinchilla {

    public static void main(String[] args) {
        Scanner read = new Scanner(System.in);
        
        int opcion = 0;
        
        while (opcion !=4){
            
            System.out.println("Menu");
            System.out.println("1. Substitute");
            System.out.println("2. Palindromas");
            System.out.println("3. Contenida o no");
            System.out.println("4. Salir");
            
            opcion = read.nextInt();
            
            switch (opcion){
                case 1: {
                    
                    System.out.println("Ingrese una cadena (con el simbolo %d): ");
                    String c1 = read.next();
                    System.out.println("Ingrese la cadena que hara la sustitucion: ");
                    String c2 = read.next();
                    
                        
                    
                    break;
                }
                case 2:{
                    System.out.println("Ingrese la palabra: ");
                    String palabra = read.next();
                    char letra;
                    String inversa;
                    int letras2=0;
                    for (int i= 0; i>palabra.length();i++){
                        letra = palabra.charAt(i);
                        letras2 = letra;    
                }
                    inversa = palabra;
                    if(letras2<=122 && letras2>=97 || letras2<=90 && letras2>=65 || (inversa.equals((palabra)))){
                           
                            System.out.println("La palabra es palindroma");
                        }else {
                            System.out.println("La palabra no es palindroma");
                        }
                    break;
                }
                case 3:{
                    String frase1;
                    System.out.println("Ingrese una cadena larga: ");
                    frase1 = read.next();
                    System.out.println("Ingrese una cadena corta: ");
                    String frase2 = read.next();
                        char letras;
                            for (int i=0; i>frase1.length();i++){
                                letras=frase1.charAt(i);
                            }
                            if (frase2.equals(frase1)){
                                    System.out.println("La cadena corta esta contenida en la cadena larga");
                                } else{
                                    System.out.println("La cadena corta NO esta contenida en la cadena larga");
                                }
                    break;
                }
                case 4:{
                    System.out.println("Ha salido del menu");
                    break;
                }
                
                
                
                
                default:
                
                
            }
                    
            
        }
    }
}
